﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Console_Linq
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Customer> custlist = new List<Customer>();
            custlist.Add(new Customer {CustomerID=1,CustomerAge=25,CustomerCity="BGL",CustomerName="John" });
            custlist.Add(new Customer { CustomerID = 2, CustomerAge = 30, CustomerName = "Smith", CustomerCity = "BGL" });
            custlist.Add(new Customer { CustomerID = 3, CustomerAge = 20, CustomerName = "Devid", CustomerCity = "BGL" });
            custlist.Add(new Customer { CustomerID = 4, CustomerAge = 20, CustomerName = "Rosy", CustomerCity = "Pune" });
            custlist.Add(new Customer { CustomerID = 5, CustomerAge = 23, CustomerName = "Tony", CustomerCity = "Delhi" });


            List<Order> ordlist = new List<Order>();
            ordlist.Add(new Order { OrderID = 1001, CustomerID = 1, ItemName = "Oneplus 6T", ItemPrice = 38000 });
            ordlist.Add(new Order { OrderID = 1002, CustomerID = 1, ItemName = "TV", ItemPrice = 38000 });

            ordlist.Add(new Order { OrderID = 1003, CustomerID = 2, ItemName = "Oneplus 6T", ItemPrice = 38000 });
            ordlist.Add(new Order { OrderID = 1004, CustomerID = 3, ItemName = "Laptop", ItemPrice = 50000 });


            string city = "BGL";
            var q = from c in custlist
                    where c.CustomerCity == city
                    orderby c.CustomerAge descending, c.CustomerName ascending
                    select c;

            foreach(var x in q)
            {
                Console.WriteLine(x.CustomerID + "  " + x.CustomerName + "  " + x.CustomerCity);
            }

            var count = (from c in custlist
                         where c.CustomerName.StartsWith("A")
                         select c).Count();
            
            

            Console.WriteLine(count);

            var obj = (from c in custlist
                       where c.CustomerID == 1
                       select c).FirstOrDefault();

            if (obj != null)
            {
                Console.WriteLine(obj.CustomerID + "  " + obj.CustomerName);
            }
            else
            {
                Console.WriteLine("Not Found");
            }



            var qdata = from c in custlist
                        where c.CustomerAge > 20
               select new { CID = c.CustomerID, CName = c.CustomerName, CCity = c.CustomerCity };

            foreach(var p in qdata)
            {
                Console.WriteLine(p.CID + "  " + p.CName + "  " + p.CCity);
            }

            var joindata = from c in custlist
                           join o in ordlist
                           on c.CustomerID equals o.CustomerID
                           select new { CID = c.CustomerID,
                               CName = c.CustomerName, OID = o.OrderID,
                               ItemName = o.ItemName, Price = o.ItemPrice };

           // dg_customers.DataSource = joindata;

            foreach(var j in joindata)
            {
            Console.WriteLine(j.CID + "  " + j.CName + "  " + j.OID + 
                                  "  " + j.ItemName + "  " + j.Price);
            }

            Console.ReadLine();






        }
    }
}
